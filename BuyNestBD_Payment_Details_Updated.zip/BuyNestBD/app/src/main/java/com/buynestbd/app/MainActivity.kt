package com.buynestbd.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A43)
private val Blue = Color(0xFF1976D2)
private val Orange = Color(0xFFFF8A3D)
private val Pale = Color(0xFFF4F7FB)

data class Product(val name: String, val category: String, val price: Int, val emoji: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BuyNestApp() }
    }
}

@Composable
fun BuyNestApp() {
    val products = listOf(
        Product("Wireless Headphone", "Electronics", 1250, "🎧"),
        Product("Smart Watch", "Electronics", 1890, "⌚"),
        Product("Cotton T-Shirt", "Fashion", 550, "👕"),
        Product("Ladies Handbag", "Fashion", 990, "👜"),
        Product("Kitchen Set", "Home & Living", 1450, "🍽️"),
        Product("Sports Shoes", "Fashion", 1750, "👟"),
        Product("Skin Care Pack", "Beauty", 780, "🧴"),
        Product("Kids Toy", "Kids", 450, "🧸")
    )
    var selectedCategory by remember { mutableStateOf("All") }
    var cartCount by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Home") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    val categories = listOf("All", "Electronics", "Fashion", "Home & Living", "Beauty", "Kids")
    val filtered = products.filter {
        (selectedCategory == "All" || it.category == selectedCategory) &&
        it.name.contains(search, ignoreCase = true)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Orange, background = Pale)) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == "Home", onClick = { page = "Home"; selectedProduct = null },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = page == "Categories", onClick = { page = "Categories"; selectedProduct = null },
                        icon = { Icon(Icons.Default.Category, null) }, label = { Text("Categories") })
                    NavigationBarItem(selected = page == "Cart", onClick = { page = "Cart"; selectedProduct = null },
                        icon = { BadgedBox(badge = { if (cartCount > 0) Badge { Text("$cartCount") } }) { Icon(Icons.Default.ShoppingCart, null) } }, label = { Text("Cart") })
                    NavigationBarItem(selected = page == "Account", onClick = { page = "Account"; selectedProduct = null },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Account") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedProduct != null) {
                    ProductDetail(selectedProduct!!, onBack = { selectedProduct = null }, onAdd = { cartCount++ })
                } else when (page) {
                    "Home" -> {
                        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BUY NEST BD", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Your Shopping, Your Nest.", color = Color(0xFFD9E8F7), fontSize = 12.sp)
                            }
                            BadgedBox(badge = { if (cartCount > 0) Badge { Text("$cartCount") } }) {
                                Icon(Icons.Default.ShoppingBag, null, tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            OutlinedTextField(value = search, onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search products...") },
                                leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                                shape = RoundedCornerShape(14.dp))
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().background(Blue, RoundedCornerShape(18.dp)).padding(18.dp)) {
                                Column {
                                    Text("Big deals. Happy shopping!", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("Discover everyday essentials at great prices.", color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    Text("SHOP NOW  →", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            Text("Shop by category", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                categories.take(3).forEach { cat ->
                                    FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat },
                                        label = { Text(cat) })
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                categories.drop(3).forEach { cat ->
                                    FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat },
                                        label = { Text(cat) })
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Popular products", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)) {
                            items(filtered) { product ->
                                ProductCard(product) { selectedProduct = product }
                            }
                        }
                    }
                    "Categories" -> {
                        Column(Modifier.padding(18.dp)) {
                            Text("Categories", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                            categories.drop(1).forEach { cat ->
                                ListItem(headlineContent = { Text(cat) }, leadingContent = { Icon(Icons.Default.Category, null) },
                                    modifier = Modifier.clickable { selectedCategory = cat; page = "Home" })
                                HorizontalDivider()
                            }
                        }
                    }
                    "Cart" -> Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Text("Your cart", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                        Text("$cartCount item(s) added", color = Color.Gray)
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text("Payment options", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
                                Spacer(Modifier.height(12.dp))
                                Text("Cash on Delivery (COD)", fontWeight = FontWeight.SemiBold)
                                Text("Pay when your order is delivered.", color = Color.Gray, fontSize = 13.sp)
                                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                                Text("bKash (Send Money)", fontWeight = FontWeight.SemiBold, color = Navy)
                                Text("01763075298", color = Blue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(10.dp))
                                Text("Nagad (Send Money)", fontWeight = FontWeight.SemiBold, color = Navy)
                                Text("01763075298", color = Blue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Text("পেমেন্ট করার পর Transaction ID অর্ডারের সাথে জমা দিন। অ্যাডমিন লেনদেন যাচাই করে পেমেন্ট অনুমোদন করবেন।",
                                    color = Color.Gray, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("নিরাপত্তা: শুধু Transaction ID লিখলেই পেমেন্ট স্বয়ংক্রিয়ভাবে নিশ্চিত হয় না।",
                                    color = Color(0xFFB45309), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("এটি এখন পেমেন্ট নির্দেশনা দেখায়; লাইভ অর্ডার, Transaction ID জমা, এবং bKash/Nagad API যাচাই এখনো সংযুক্ত নয়।",
                            color = Color.Gray, fontSize = 12.sp)
                    }
                    else -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Person, null, tint = Blue, modifier = Modifier.size(54.dp))
                        Text("My Account", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Customer sign-in will be added in the next stage.", color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun ProductCard(product: Product, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(12.dp)) {
            Box(Modifier.fillMaxWidth().height(92.dp).background(Pale, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center) { Text(product.emoji, fontSize = 42.sp) }
            Spacer(Modifier.height(8.dp))
            Text(product.name, fontWeight = FontWeight.SemiBold, color = Navy, maxLines = 1)
            Text(product.category, color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("৳${product.price}", color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(Icons.Default.AddCircle, null, tint = Orange)
            }
        }
    }
}

@Composable
fun ProductDetail(product: Product, onBack: () -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("← Back", color = Blue, modifier = Modifier.clickable { onBack() })
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().height(220.dp).background(Color.White, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            Text(product.emoji, fontSize = 90.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text(product.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text(product.category, color = Color.Gray)
        Text("৳${product.price}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)
        Spacer(Modifier.height(12.dp))
        Text("Product details and seller information can be managed from the store admin panel.")
        Spacer(Modifier.weight(1f))
        Button(onClick = { onAdd() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.AddShoppingCart, null)
            Spacer(Modifier.width(8.dp))
            Text("Add to Cart")
        }
    }
}
